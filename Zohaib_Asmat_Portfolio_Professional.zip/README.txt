ZOHAIB ASMAT — PROFESSIONAL PORTFOLIO

This is the redesigned professional version of the portfolio.

Theme:
- Executive pharmaceutical / healthcare aesthetic
- Navy + white + teal visual system
- Responsive layout
- Modern typography and subtle animations
- Mobile navigation
- Clickable email and phone

Files:
index.html
style.css
script.js
profile.jpg

To view:
Open index.html in Chrome or Microsoft Edge.

Keep all files together when uploading to a hosting service.
